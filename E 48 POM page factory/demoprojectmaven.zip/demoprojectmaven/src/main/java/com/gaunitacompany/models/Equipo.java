package com.gaunitacompany.models;

public class Equipo {

}
