package com.gaunitacompany.models;
import java.util.ArrayList;
import java.util.Scanner;

public class LigaFutbol {
    private static ArrayList<Equipo> equipos = new ArrayList<>();
    private static ArrayList<Jugador> jugadores = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;
        while (!salir) {
            System.out.println("Menú principal:");
            System.out.println("1. Crear jugador");
            System.out.println("2. Crear equipo");
            System.out.println("3. Asignar jugador a equipo");
            System.out.println("4. Seleccionar jugador");
            System.out.println("5. Seleccionar equipo");
            System.out.println("6. Mostrar lista de jugadores");
            System.out.println("7. Mostrar lista de equipos");
            System.out.println("8. Eliminar jugador");
            System.out.println("9. Eliminar equipo");
            System.out.println("10. Salir");
            int opcion = scanner.nextInt();
            switch (opcion) {
                case 1:
                    crearJugador(scanner);
                    break;
                case 2:
                    crearEquipo(scanner);
                    break;
                case 3:
                    asignarJugadorAEquipo(scanner);
                    break;
                case 4:
                    seleccionarJugador(scanner);
                    break;
                case 5:
                    seleccionarEquipo(scanner);
                    break;
                case 6:
                    mostrarListaJugadores();
                    break;
                case 7:
                    mostrarListaEquipos();
                    break;
                case 8:
                    eliminarJugador(scanner);
                    break;
                case 9:
                    eliminarEquipo(scanner);
                    break;
                case 10:
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    

    private static void crearEquipo(Scanner scanner) {
        System.out.print("Ingresa el nombre del equipo: ");
        String nombre = scanner.next();
        Equipo equipo = new Equipo(nombre);
        equipos.add(equipo);
    }

    private static void asignarJugadorAEquipo(Scanner scanner) {
        if (jugadores.size() > 0 && equipos.size() > 0) {
            System.out.println("Selecciona un jugador:");
            for (int i = 0; i < jugadores.size(); i++) {
                System.out.println(i + ". " + jugadores.get(i).getNombre());
            }
            int opcionJugador = scanner.nextInt();
            if (opcionJugador >= 0 && opcionJugador < jugadores.size()) {
                Jugador jugador = jugadores.get(opcionJugador);
                System.out.println("Selecciona un equipo:");
                for (int i = 0; i < equipos.size(); i++) {
                    System.out.println(i + ". " + equipos.get(i).getNombre());
                }
                int opcionEquipo = scanner.nextInt();
                if (opcionEquipo >= 0 && opcionEquipo < equipos.size()) {
                    Equipo equipo = equipos.get(opcionEquipo);
                    jugador.setEquipo(equipo);
                    equipo.agregarJugador(jugador);
                } else {
                    System.out.println("Opción inválida.");
                }
            } else {
                System.out.println("Opción inválida.");
            }
        } else {
            if (jugadores.size() == 0) {
                System.out.println("No hay jugadores disponibles.");
            }
            if (equipos.size() == 0) {
                System.out.println("No hay equipos disponibles.");
            }
        }
    }

    private static void seleccionarJugador(Scanner scanner) {
        if (jugadores.size() > 0) {
            System.out.println("Selecciona un jugador:");
            for (int i = 0; i < jugadores.size(); i++) {
                System.out.println(i + ". " + jugadores.get(i).getNombre());
            }
            int opcionJugador = scanner.nextInt();
            if (opcionJugador >= 0 && opcionJugador < jugadores.size()) {
                Jugador jugador = jugadores.get(opcionJugador);
                boolean regresar = false;
                while (!regresar) {
                    System.out.println("Menú de jugador:");
                    System.out.println("1. Ver detalles");
                    System.out.println("2. Cambiar nombre");
                    System.out.println("3. Cambiar equipo");
                    System.out.println("4. Regresar al menú principal");
                    int opcion = scanner.nextInt();
                    switch (opcion) {
                        case 1:
                            System.out.println("Nombre: " + jugador.getNombre());
                            if (jugador.getEquipo() != null) {
                                System.out.println("Equipo: " + jugador.getEquipo().getNombre());
                            } else {
                                System.out.println("Equipo: Ninguno");
                            }
                            break;
                        case 2:
