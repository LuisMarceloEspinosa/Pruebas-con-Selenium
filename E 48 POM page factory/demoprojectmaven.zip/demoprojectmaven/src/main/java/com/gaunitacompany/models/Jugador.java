package com.gaunitacompany.models;

private static void crearJugador(Scanner scanner) {
        System.out.print("Ingresa el nombre del jugador: ");
        String nombre = scanner.next();
        Jugador jugador = new Jugador(nombre);
        jugadores.add(jugador);
        if (equipos.size() > 0) {
            System.out.println("Selecciona un equipo para el jugador:");
            for (int i = 0; i < equipos.size(); i++) {
                System.out.println(i + ". " + equipos.get(i).getNombre());
            }
            int opcionEquipo = scanner.nextInt();
            if (opcionEquipo >= 0 && opcionEquipo < equipos.size()) {
                Equipo equipo = equipos.get(opcionEquipo);
                jugador.setEquipo(equipo);
                equipo.agregarJugador(jugador);
            } else {
                System.out.println("Opción inválida.");
            }
        } else {
            System.out.println("No hay equipos disponibles.");
        }
    }
