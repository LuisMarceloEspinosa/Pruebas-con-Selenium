package com.gaunitacompany.pages;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class WikipediaPage extends BasePage{
    By myLocator = By.id("searchInput");
    By logoLocator = By.cssSelector(".central-textlogo__image");
    By searchButtonLocator = By.cssSelector("button[type=submit]");
    By buscarLocator = By.cssSelector(".cdx-text-input__input");
    //  @FindBy(css = ".cdx-text-input__input")
    //  private WebElement inputSearch;
    @FindBy(css =  "div#main-port")
    private WebElement elementToScroll;
   

    public WikipediaPage(WebDriver driver, String url) {
        super(driver);
        visit(url);
    }
    public void buscar(String text){
        sendKeys(text, buscarLocator);
    }
    public void scroll(){
        Scrollpage(elementToScroll);
    }
    public String tituloString(){
        getTextDriver();
    }
    public void myLocator(String term) {
        
    }
}


