package com.gaunitacompany.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class GooglePage extends BasePage {

    public GooglePage(WebDriver driver, String url) {
        super(driver);
        visit(url);
    }
    By textArea = By.cssSelector("textarea#APjFqb");
    
    
    
    
    public void buscarGoogle(String text){
        sendKeys(text, textArea);
    }
    
}
