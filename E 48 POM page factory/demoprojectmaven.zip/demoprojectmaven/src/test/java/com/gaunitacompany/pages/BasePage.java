package com.gaunitacompany.pages;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BasePage {
     WebDriver driver;
    //constructor
    public BasePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
    
    public void Scrollpage(WebElement element){
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", element);

    }
    public void driverMaximize(){
        driver.manage().window().maximize();
    }
    public WebElement findElement(By locator){
        return driver.findElement(locator);
    }
    public List<WebElement> findElements(By locator){
        return driver.findElements(locator);
    }
    public String getTextDriver(){
        return driver.getTitle();
    }
    public String getTextWE(WebElement element){
        return element.getText();
    }
    public String getText(By locator){
        return driver.findElement(locator).getText();
    }
    public void sendKeys(String keys, By locator){
        driver.findElement(locator).sendKeys(keys, Keys.ENTER);
    }
    public void click(By locator){
        driver.findElement(locator).click();
    }
    public Boolean isDisplayed(By locator){
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }
    public void visit(String url){
        driver.get(url);
    }
    public void implicitWait(int timer){
        driver.manage().timeouts().implicitlyWait(timer, TimeUnit.SECONDS);
    }
    public void explicitWait(int durationSec, int reviewSec, By locator){
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
        .withTimeout(Duration.ofSeconds(durationSec)) 
        .pollingEvery(Duration.ofSeconds(reviewSec))
        .ignoring(NoSuchElementException.class)
        .withMessage("Elemento no encontrado en el tiempo especificado");  
        wait.until(new Function<WebDriver, WebElement>() { public WebElement apply(WebDriver driver) { return driver.findElement(locator); } });

    }
    public String getAtribute(WebElement element, String atribute){
        String atr = element.getAttribute(atribute);
        return atr;
    }
    public String getCurrentUrl(){
        String url = driver.getCurrentUrl();
        return url;
    }
}
