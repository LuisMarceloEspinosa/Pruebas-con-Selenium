package com.gaunitacompany;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gaunitacompany.pages.GooglePage;
import com.gaunitacompany.pages.WikipediaPage;

import io.github.bonigarcia.wdm.WebDriverManager;

class BaseTest {
    WebDriver driver = null;

    WikipediaPage wikipage;

    @BeforeEach
    public void initChrome(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
    }
    @AfterEach
    public void salir(){
        // driver.quit();
    }
    @Test
    void testPrimero(){
        
        GooglePage gopage = new GooglePage(driver, "https://www.google.com/");
        gopage.buscarGoogle("Selenium");
        
    }
     @Test
    void testWiki(){
        
        WikipediaPage wikipage = new WikipediaPage(driver, "https://es.wikipedia.org/wiki/Wikipedia:Portada");
        wikipage.scroll();
        
        
    }


    
    
}
