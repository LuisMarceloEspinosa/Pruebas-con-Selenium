package com.gaunitacompany;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByTagName;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Answers.values;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gaunitacompany.pages.GooglePage;
import com.gaunitacompany.pages.WikipediaPage;

import io.github.bonigarcia.wdm.WebDriverManager;


class ApplicationTest extends BaseTest {
    @Test
    void testPrimero(){
        //busqueda en input de wikipedia
        WikipediaPage wikipage = getWikipage();
        wikipage.buscar("selenium");
    }
    @Test
    void testSegundo(){
        //busqueda en input de wikipedia
        GooglePage googlepage = getGooglePage();
        googlepage.buscar("wikipedia");
    }
    @Test
    void testTercero(){
        //busqueda en input de wikipedia
        WikipediaPage wikiportada = getWikiPortada();
        wikiportada.driverMaximize();
        wikiportada.scroll();
    }
     @Test public void titledri(){
         WikipediaPage wikiportada = getWikiPortada();
        wikiportada.tituloString()
    }




    @Test
    public void testGoogle(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.google.com/");
        
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, 15);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("textarea#APjFqb")));

        driver.findElement(By.cssSelector("textarea#APjFqb")).sendKeys("wikipedia");
    }
    @Test
    public void testGitHub(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.github.com/");
        
        driver.manage().window().maximize(); 

        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.HeaderMenu-link--sign-in"))).click();
    }
    // PageFactory.initElements(driver, this)
    @Test
    public void testWiki(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();


        driver.get("https://es.wikipedia.org/wiki/Wikipedia:Portada");
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div#main-port")));
        WebElement element = driver.findElement(By.cssSelector("div#main-port"));
        // Crea una instancia de JavascriptExecutor para realizar el desplazamiento
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        
        // // Desplázate hacia la posición de la lista de categorías
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", element);

        // Espera un momento para que se complete el desplazamiento
        // try {
        //     Thread.sleep(1000); // Espera por 1 segundo
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }
    }
    @Test 
    public void testFacebook(){
         WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();


        driver.get("https://facebook.com");
        driver.manage().window().maximize();
        // driver.findElement(By.cssSelector("a[title=Mostrar más idiomas]"));
        driver.findElement(By.cssSelector("i.sp_EP9wX8qDDvu.sx_0de3e6")).click();
    }

    @Test
    public void busquedaGoogle(){
         WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("https://www.google.com/");
        //Realizar una búsqueda en Google y hacer clic en el primer enlace de resultados, utilizando Implicit Wait.
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
        WebElement bus = driver.findElement(By.cssSelector("#APjFqb"));
        bus.sendKeys("egg");
        bus.sendKeys(Keys.ENTER);

       WebElement primerResu = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div[1]/div/div/a"));
       primerResu.click();
    }
@Test
    public void esperaImgBBC(){
        
         WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://www.bbc.com/mundo");
        // Objetivo: Navegar a la página de tecnología de la BBC, 
        // esperar a que se cargue la imagen principal utilizando Explicit Wait, y luego hacer clic en ella.
        
        WebDriverWait wait = new WebDriverWait(driver, 10); 
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"main-wrapper\"]/header/nav/div/div[1]/div/ul/li[9]/a")));
        element.click();
        driver.findElement(By.cssSelector("a[href='https://www.bbc.com/mundo/articles/c25gd1p015xo']")).click();
        //  try {
        //     // Adds the cookie into current browser context
        //     driver.manage().addCookie(new Cookie("data-cookie-banner", "accept"));
        //     Thread.sleep(6000);
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // } finally {
        //     // Time.sleep(5000);
        //     driver.findElement(By.cssSelector("[data-cookie-banner=accept]")).click();
        // driver.findElement(By.cssSelector("a[href='https://www.bbc.com/mundo/articles/c25gd1p015xo']")).click();
        // }
    }

    @Test
    public void buscarEnWiki(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        
        driver.navigate().to("https://es.wikipedia.org/");
        //Objetivo: Navegar a la página de búsqueda en Wikipedia, 
        
        WebElement buscar = driver.findElement(By.cssSelector(".cdx-text-input__input"));
        buscar.sendKeys("america");
        //buscar un término y esperar a que se cargue la página de resultados utilizando Fluent Wait.
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
        .withTimeout(Duration.ofSeconds(30)) 
        .pollingEvery(Duration.ofSeconds(5))
        .ignoring(NoSuchElementException.class)
        .withMessage("Elemento no encontrado en el tiempo especificado");  
        wait.until(new Function<WebDriver, WebElement>() { public WebElement apply(WebDriver driver) { return driver.findElement(By.cssSelector(".cdx-text-input__input")); } });
    }
    @Test public void testWikipediaTitle() { 
          WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.wikipedia.org");
        String element = driver.getTitle();
        assertEquals("Wikipedia", element);
        driver.quit();
}
   //// HASTA ACA HICE
    @Test public void buttonGoogle(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.google.com");
        WebElement element = driver.findElement(By.cssSelector("input.gNO89b"));
        String google = element.getAttribute("value");
        assertEquals(google, "Buscar con Google");
    }
      @Test public void twitter(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.twitter.com");
         WebElement element = driver.findElement(By.cssSelector("a[data-testid=loginButton]"));
         String linkEsperado = element.getAttribute("href");
         assertEquals(linkEsperado, "https://twitter.com/login");
    }
    
     @Test public void youtube(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.youtube.com/");
        String element = driver.getTitle();
        assertNotEquals(element, "");
    }
     @Test public void testWiki2() { 
          WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://en.wikipedia.org/wiki/Main_Page");
        WebElement findE = driver.findElement(By.cssSelector("img.mw-logo-tagline"));
        String findEsperado = findE.getAttribute("alt");
        assertNotEquals(findEsperado, "Enciclopedia Libre");
        
     }
      @Test public void twitterNotEquals() { 
          WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.twitter.com");
         WebElement element = driver.findElement(By.cssSelector("a[data-testid=loginButton]"));
         String textEsperado = element.getText();
         System.out.println(textEsperado);
        assertNotEquals(textEsperado, "Log In");
     }
     @Test public void testLogoGoogle(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.google.com");
        WebElement logo = driver.findElement(By.cssSelector("img.lnXdpd"));
        assertTrue(logo.isDisplayed());
    }
    @Test public void testAmazon(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.amazon.com/-/es/Dr-Jaime-Leal-Godinez/dp/177784732X/?_encoding=UTF8&pd_rd_w=LeaWr&content-id=amzn1.sym.cfca505f-0d6d-44b6-b071-d4633ed39e36&pf_rd_p=cfca505f-0d6d-44b6-b071-d4633ed39e36&pf_rd_r=AV6SJBJHTNTKNYF2AGWN&pd_rd_wg=8HrFh&pd_rd_r=46b597c1-f648-43ce-9637-bf2d008f4f5e&ref_=pd_gw_exports_top_sellers_by_gl_rec");
        WebElement disponible = driver.findElement(By.cssSelector("span.a-size-medium.a-color-success"));
        System.out.println(disponible);
        // assertTrue(disponible.isDisplayed());
        assertTrue(disponible.isEnabled());

    }
    @Test public void testContacto(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://fabricsushi.com.ar/");
        driver.findElement(By.cssSelector("button.close-reveal-modal")).click();
        WebElement atributo = driver.findElement(By.xpath("/html/body/header/nav/ul/li[10]/a"));
        assertTrue(atributo.isDisplayed());
    }
    // @Test public void buttonDisponible(){
    //     WebDriverManager.chromedriver().setup();
    //     WebDriver driver = new ChromeDriver(); 
    //     driver.get("https://www.google.com");
    //      WebElement element = driver.findElement(By.cssSelector("input.gNO89b"));
    //     assertFalse(element.isEnabled());
    // }
    @Test public void checkGitHub(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.google.com");
        WebElement element = driver.findElement(By.cssSelector("input.gNO89b"));
        
    }
    @Test
    void testGoogleSearchButtonDisabled2() {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.google.com");

        // Verificar que la página de inicio de Google esté cargada
        assertEquals(driver.getTitle(), "Google");

        // Verificar que el elemento de búsqueda esté visible
        assertTrue(driver.findElement(By.name("q")).isDisplayed());

        // Esperar a que el botón de búsqueda esté habilitado
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.elementToBeClickable(By.name("btnK")));

        // Verificar que el botón de búsqueda esté deshabilitado
        assertFalse(driver.findElement(By.name("btnK")).isEnabled());

        // Verificar que el tamaño del logo de Google sea mayor a 0
        assertTrue(driver.findElement(By.className("lnXdpd")).getSize().getHeight() > 0);

        driver.quit();
    }
    @Test
        void ejer1(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.google.com");
            WebElement searchInput = driver.findElement(By.id("APjFqb"));
            assertTrue(searchInput.getAttribute("value").isEmpty());
            WebElement searchButton = driver.findElement(By.name("btnK"));
            assertTrue(searchButton.isEnabled());

        }
        @Test
        void testBing(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.bing.com/?setmkt=es-ar&setlang=es");
            WebElement searchBar = driver.findElement(By.name("q"));
            assertTrue(searchBar.isDisplayed());
            WebElement suggestion = driver.findElement(By.cssSelector("div.sa_as"));
            assertFalse(suggestion.isDisplayed());

        }
         @Test
        void testMozilla(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.mozilla.org/es-AR/firefox/new/");
            WebElement logo = driver.findElement(By.cssSelector("img.c-navigation-logo-image"));
            assertTrue(logo.isDisplayed());
            String url = driver.getCurrentUrl();
            assertEquals("https://www.mozilla.org/es-AR/firefox/new/", url);
            
        }
         @Test
        void testGitHubJob(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://github.com/about/careers");
            WebElement button = driver.findElement(By.cssSelector("#engineering > div > h3 > button"));
            button.click();
            List<WebElement> elements = driver.findElements(By.cssSelector("#engineering > ul > li"));
            assertFalse(elements.isEmpty());
            int numElements = elements.size();
            System.out.println(numElements);
    
            String targetText = "software engineer";
            int countStarWars = 0;
        
            for (WebElement element : elements) {
                String text = element.getText();
                System.out.println("Texto del elemento: " + text);
                
        
                if (text.toLowerCase().startsWith(targetText) || text.toLowerCase().contains(targetText)) {
                    countStarWars++;
                }
            } 
            assertTrue(countStarWars > 0);
        
            System.out.println("Número de elementos que comienzan o contienen 'star wars': " + countStarWars);
        
            
        }
        @Test
        public void GoogleNull()  {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com/");
        try {
            driver.findElement(By.id("elementoInexistente"));
        }
        catch (Exception NoSuchElementException) {
            }
}
     @Test 
        void wikiImplicit(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.wikipedia.org/");
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

            String titulo = driver.findElement(By.cssSelector("span.central-textlogo__image")).getText();

            assertEquals(titulo, "Wikipedia");
        }
    @Test 
    public void GoggleBusqueda() {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.google.com/");
        driver.findElement(By.cssSelector("textarea#APjFqb")).sendKeys("nintendo", Keys.ENTER);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText("https"))).click();
        driver.quit();
    }
     @Test 
        void wikiImplicit2(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://en.wikipedia.org/wiki/Main_Page");
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            driver.findElement(By.cssSelector("body")).sendKeys(Keys.END);
            driver.findElement(By.cssSelector("span[lang=es]")).click();
            WebElement atribute = driver.findElement(By.cssSelector("img.mw-logo-tagline"));
            String atr = atribute.getAttribute("alt");
            assertEquals(atr, "La enciclopedia libre");
            driver.quit();
        }
     @Test 
        void wikiImplici(){
            WebDriverManager.chromedriver().setup();
            WebDriver driver = new ChromeDriver();
            driver.get("https://www.youtube.com/");
            
            WebDriverWait wait = new WebDriverWait(driver, 10);
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input#search")));
            WebElement inputSearch = driver.findElement(By.cssSelector("input#search"));
            inputSearch.sendKeys("Futbol", Keys.ENTER);
        }
    
    



}
