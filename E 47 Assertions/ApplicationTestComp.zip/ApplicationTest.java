package com.gaunitacompany;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By.ByTagName;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Answers.values;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;


class ApplicationTest {

    @Test
    public void testGoogle(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.google.com/");
        
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, 15);

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("textarea#APjFqb")));

        driver.findElement(By.cssSelector("textarea#APjFqb")).sendKeys("wikipedia");



        
        



       
        
        // driver.get("https://www.youtube.com/watch?v=g_nf2qlh27Y");
        // driver.manage().window().maximize();
         
        // WebDriverWait wait = new WebDriverWait(driver, 45);
        // wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div#title.ytd-comments-header-renderer")));

        // WebElement videoElement = driver.findElement(By.cssSelector("div#title.ytd-comments-header-renderer"));

        // JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        // jsExecutor.executeScript("arguments[0].scrollIntoView(true);", videoElement);

        
        

        // driver.get("https://www.google.com");
        
        
        // driver.manage().window().maximize();

        // driver.get("https://openai.com");

        // driver.manage().window().setSize(new Dimension(500, 500));

        // driver.manage().window().setPosition(new Point(200, 200));

        // driver.get("https://www.wikipedia.org");

        // driver.manage().window().maximize();
        //   driver.close();

        // driver.navigate().back();

        // driver.navigate().forward();

      
        
        // WebElement textbox = driver.findElement(By.id("APjFqb"));

        // WebElement submitButton = driver.findElement(By.cssSelector("gNO89b"));

        // textbox.sendKeys("selenium");
        // submitButton.click();


    //    driver.get("https://www.thisisfeliznavidad.com/por-producto/retro-sweaters/?mpage=5");

    //    List<WebElement> elements = driver.findElements(By.xpath("//div[contains(text(), 'Star Wars')]"));

    //    System.out.println(elements.size());

        // driver.get("https://www.google.com/");

        // WebElement text1 = driver.findElement(By.cssSelector("textarea#APjFqb"));
        // text1.sendKeys("wikipedia");


        // driver.navigate().to("https://github.com/");
        // driver.findElement(By.cssSelector("button.HeaderMenu-link[aria-expanded=false]")).click();
       
        // driver.navigate().to("https://twitter.com/i/flow/signup");
        // // driver.findElement(By.cssSelector("span.css-18t94o4[role=button]")).click();
        // WebDriverWait wait = new WebDriverWait(driver, 10);
        // WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("span.css-18t94o4[role=button]")));
        // element.click();

       

        //  driver.findElement(By.cssSelector("body")).sendKeys(Keys.END);

       


    }
    @Test
    public void testGitHub(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        
        driver.get("https://www.github.com/");
        
        driver.manage().window().maximize(); 

        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a.HeaderMenu-link--sign-in"))).click();
    }
    @Test
    public void testWiki(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();


        driver.get("https://es.wikipedia.org/wiki/Wikipedia:Portada");
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, 15);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div#main-port")));
        WebElement element = driver.findElement(By.cssSelector("div#main-port"));
        // Crea una instancia de JavascriptExecutor para realizar el desplazamiento
        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        
        // // Desplázate hacia la posición de la lista de categorías
        jsExecutor.executeScript("arguments[0].scrollIntoView(true);", element);

        // Espera un momento para que se complete el desplazamiento
        // try {
        //     Thread.sleep(1000); // Espera por 1 segundo
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // }
    }
    @Test 
    public void testFacebook(){
         WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();


        driver.get("https://facebook.com");
        driver.manage().window().maximize();
        // driver.findElement(By.cssSelector("a[title=Mostrar más idiomas]"));
        driver.findElement(By.cssSelector("i.sp_EP9wX8qDDvu.sx_0de3e6")).click();
    }

    @Test
    public void busquedaGoogle(){
         WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.navigate().to("https://www.google.com/");
        //Realizar una búsqueda en Google y hacer clic en el primer enlace de resultados, utilizando Implicit Wait.
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
       
        WebElement bus = driver.findElement(By.cssSelector("#APjFqb"));
        bus.sendKeys("egg");
        bus.sendKeys(Keys.ENTER);

       WebElement primerResu = driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div[1]/div/div/a"));
       primerResu.click();
    }
@Test
    public void esperaImgBBC(){
        
         WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.navigate().to("https://www.bbc.com/mundo");
        // Objetivo: Navegar a la página de tecnología de la BBC, 
        // esperar a que se cargue la imagen principal utilizando Explicit Wait, y luego hacer clic en ella.
        
        WebDriverWait wait = new WebDriverWait(driver, 10); 
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"main-wrapper\"]/header/nav/div/div[1]/div/ul/li[9]/a")));
        element.click();
        driver.findElement(By.cssSelector("a[href='https://www.bbc.com/mundo/articles/c25gd1p015xo']")).click();
        //  try {
        //     // Adds the cookie into current browser context
        //     driver.manage().addCookie(new Cookie("data-cookie-banner", "accept"));
        //     Thread.sleep(6000);
        // } catch (InterruptedException e) {
        //     e.printStackTrace();
        // } finally {
        //     // Time.sleep(5000);
        //     driver.findElement(By.cssSelector("[data-cookie-banner=accept]")).click();
        // driver.findElement(By.cssSelector("a[href='https://www.bbc.com/mundo/articles/c25gd1p015xo']")).click();
        // }
    }

    @Test
    public void buscarEnWiki(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        
        driver.navigate().to("https://es.wikipedia.org/");
        //Objetivo: Navegar a la página de búsqueda en Wikipedia, 
        
        WebElement buscar = driver.findElement(By.cssSelector(".cdx-text-input__input"));
        buscar.sendKeys("america");
        //buscar un término y esperar a que se cargue la página de resultados utilizando Fluent Wait.
        Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
        .withTimeout(Duration.ofSeconds(30)) 
        .pollingEvery(Duration.ofSeconds(5))
        .ignoring(NoSuchElementException.class)
        .withMessage("Elemento no encontrado en el tiempo especificado");  
        wait.until(new Function<WebDriver, WebElement>() { public WebElement apply(WebDriver driver) { return driver.findElement(By.cssSelector(".cdx-text-input__input")); } });
    }
    @Test public void testWikipediaTitle() { 
          WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.wikipedia.org");
        String element = driver.getTitle();
        assertEquals("Wikipedia", element);
        driver.quit();
}
    @Test public void buttonGoogle(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.google.com");
        WebElement element = driver.findElement(By.cssSelector("input.gNO89b"));
        String google = element.getAttribute("value");
        assertEquals(google, "Buscar con Google");
    }
      @Test public void twitter(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.twitter.com");
         WebElement element = driver.findElement(By.cssSelector("a[data-testid=loginButton]"));
         String linkEsperado = element.getAttribute("href");
         assertEquals(linkEsperado, "https://twitter.com/login");
    }
    
     @Test public void youtube(){
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.youtube.com/");
        String element = driver.getTitle();
        assertNotEquals(element, "");
    }
     @Test public void testWiki2() { 
          WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://en.wikipedia.org/wiki/Main_Page");
        WebElement findE = driver.findElement(By.cssSelector("img.mw-logo-tagline"));
        String findEsperado = findE.getAttribute("alt");
        assertNotEquals(findEsperado, "Enciclopedia Libre");
        
     }
      @Test public void twitterNotEquals() { 
          WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver(); 
        driver.get("https://www.twitter.com");
         WebElement element = driver.findElement(By.cssSelector("a[data-testid=loginButton]"));
         String textEsperado = element.getText();
         System.out.println(textEsperado);
        assertNotEquals(textEsperado, "Log In");
     }

}
